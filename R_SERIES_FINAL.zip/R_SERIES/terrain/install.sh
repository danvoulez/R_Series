#!/bin/bash
set -e

echo "🔧 Instalando LogLine Terrain no Ubuntu..."

INSTALL_DIR="$HOME/.logline"
BIN_PATH="/usr/local/bin/logline"

mkdir -p "$INSTALL_DIR"
cp -r core/* "$INSTALL_DIR/"

chmod +x "$INSTALL_DIR/run_bootstrap.sh"

echo "✅ Arquivos copiados para $INSTALL_DIR"

# Instalar atalho global se possível
if [ -w /usr/local/bin ]; then
  echo "#!/bin/bash" > "$BIN_PATH"
  echo "$INSTALL_DIR/run_bootstrap.sh \"$@\"" >> "$BIN_PATH"
  chmod +x "$BIN_PATH"
  echo "✅ Comando 'logline' instalado globalmente."
else
  echo "⚠️ Sem permissões para /usr/local/bin. Use: $INSTALL_DIR/run_bootstrap.sh"
fi

echo "🚀 Executando bootstrap..."
"$INSTALL_DIR/run_bootstrap.sh"

echo '🎉 LogLine Terrain instalado com sucesso!'
