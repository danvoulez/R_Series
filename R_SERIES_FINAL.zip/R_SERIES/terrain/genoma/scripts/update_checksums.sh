#!/usr/bin/env bash
set -euo pipefail

ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )/.." && pwd )"

find "$ROOT" -name '*.wasm' | while read -r wasm; do
  sha="$(sha256sum "$wasm" | cut -d' ' -f1)"
  # Replace placeholder in any .logline referencing this module
  grep -rl --null "$wasm" "$ROOT" | xargs -0 sed -i "s/PLACEHOLDER_SHA/${sha}/g"
done
