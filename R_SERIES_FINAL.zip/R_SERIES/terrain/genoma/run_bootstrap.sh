#!/usr/bin/env bash
set -euo pipefail

ROOT=/opt/logline
export PATH="$ROOT/bin:$PATH"

cd "$ROOT"

# Atualiza checksums WASM antes da execução
scripts/update_checksums.sh

# Inicia o kernel declarativo
logline run TERRENO_GENOMA_R/0_bootstrap.logline
