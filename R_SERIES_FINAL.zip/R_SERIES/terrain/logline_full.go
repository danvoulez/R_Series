
package main

import (
  "encoding/json"
  "fmt"
  "io/ioutil"
  "os"
  "os/exec"
  "path/filepath"
  "strings"
)

type LoglinePack struct {
  PackID      string   `json:"pack_id"`
  Entrypoint  string   `json:"entrypoint"`
  Version     string   `json:"version"`
  Description string   `json:"description"`
  Author      string   `json:"author"`
  Files       []string `json:"files"`
}

func runLoglineContract(path string) {
  fmt.Printf("📘 Interpretando contrato: %s\n", path)
  content, err := ioutil.ReadFile(path)
  if err != nil {
    fmt.Printf("Erro ao ler o arquivo: %v\n", err)
    os.Exit(1)
  }
  lines := strings.Split(string(content), "\n")
  for _, line := range lines {
    if strings.HasPrefix(line, "type:") {
      fmt.Printf("🔹 %s\n", line)
    }
  }
  fmt.Println("✅ Execução simbólica concluída.")
}

func runShellSpan(span string) {
  fmt.Printf("💻 Executando comando: %s\n", span)
  parts := strings.Fields(span)
  if len(parts) == 0 {
    fmt.Println("Comando vazio.")
    return
  }
  cmd := exec.Command(parts[0], parts[1:]...)
  cmd.Stdout = os.Stdout
  cmd.Stderr = os.Stderr
  err := cmd.Run()
  if err != nil {
    fmt.Printf("Erro ao executar: %v\n", err)
    os.Exit(1)
  }
}

func runPack(path string) {
  fmt.Printf("📦 Executando pack simbólico: %s\n", path)
  f, err := os.Open(path)
  if err != nil {
    fmt.Printf("Erro ao abrir o arquivo: %v\n", err)
    os.Exit(1)
  }
  defer f.Close()

  var pack LoglinePack
  err = json.NewDecoder(f).Decode(&pack)
  if err != nil {
    fmt.Printf("Erro ao ler o pack: %v\n", err)
    os.Exit(1)
  }

  fmt.Printf("🧩 Entrypoint: %s\n", pack.Entrypoint)
  if _, err := os.Stat(pack.Entrypoint); err == nil {
    runLoglineContract(pack.Entrypoint)
    if _, err := os.Stat("install.sh"); err == nil {
      fmt.Println("🚀 Instalando via install.sh")
      _ = exec.Command("bash", "install.sh").Run()
    }
  } else {
    fmt.Printf("❌ Arquivo de entrada não encontrado: %s\n", pack.Entrypoint)
    os.Exit(1)
  }
}

func main() {
  if len(os.Args) < 3 || os.Args[1] != "run" {
    fmt.Println("🌀 logline CLI - Uso:")
    fmt.Println("  logline run contrato.logline")
    fmt.Println("  logline run pacote.loglinepack")
    os.Exit(1)
  }

  target := os.Args[2]
  ext := filepath.Ext(target)

  switch ext {
  case ".loglinepack":
    runPack(target)
  case ".logline":
    runLoglineContract(target)
  default:
    fmt.Printf("❌ Tipo de arquivo não suportado: %s\n", ext)
    os.Exit(1)
  }
}
