#!/bin/bash
PORT=443
CERT_PATH="/opt/logline/ssl/server.pem"

# Gera certificado autoassinado se não existir
if [[ ! -f "$CERT_PATH" ]]; then
  mkdir -p /opt/logline/ssl
  openssl req -new -x509 -days 365 -nodes \
    -out "$CERT_PATH" -keyout "$CERT_PATH" \
    -subj "/C=PT/ST=Lisboa/O=VoulezVous/CN=voulezvous.ai"
fi

# Servidor HTTPS simbólico com execução de contrato
while true; do
  { echo -ne "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n"; \
    echo '{"contract":"api_query.logline"}' | logline run /opt/logline/contracts/api_run.logline; \
  } | openssl s_server -quiet -accept "$PORT" -cert "$CERT_PATH" -key "$CERT_PATH"
done
