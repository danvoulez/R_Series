#!/bin/bash
PORT=8000
echo "🌐 Servindo API LogLine em http://0.0.0.0:$PORT ..."

while true; do
  { echo -ne "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n";     echo '{"contract":"api_query.logline"}' | logline run /opt/logline/contracts/api_run.logline;   } | nc -l -p "$PORT" -q 1
done
