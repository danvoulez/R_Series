# LOGLINE GLOBAL — Núcleo de Instalação

Este pacote instala a **linha do tempo simbólica global (LogLine)** com suporte a:

- 🌐 Multi-tenancy transparente
- 🧠 Rastreabilidade auditável via `.jsonl`
- 🐘 Sincronização com PostgreSQL (modo Supabase)
- 🍃 Estrutura flexível tipo MongoDB
- 🔁 Execução e validação automática de spans

### Inclui:

- `init_storage.logline`: inicialização do ambiente (jsonl, pg, etc)
- `sync_jsonl_to_pg.logline`: sincronização automática entre JSONL ↔ PostgreSQL
- `logline_read_write_policy.logline`: permissões de acesso simbólico
- `logline_maintenance_master.logline`: tarefas de manutenção e integridade
- `politica_de_registros.logline` / `politica_de_regras.logline`: regras institucionais
- `audit.logline`, `spans_batch.logline`, `span_scrubber.logline`: manipulação segura
- `route_span.logline`: roteamento interno entre contratos
- `test_*.logline`: verificação do ambiente

Use com `logline run` para ativar, ou integre no bootstrap global.
