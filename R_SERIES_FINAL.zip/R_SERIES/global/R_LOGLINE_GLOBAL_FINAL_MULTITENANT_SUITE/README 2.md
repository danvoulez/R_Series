# LogLine API Híbrida — HTTP + HTTPS

Este pacote ativa a API do LogLine em dois canais:

- 🌍 http://164.92.209.55:8000 (público IP)
- 🔒 https://voulezvous.ai (certificado autoassinado, porta 443)

## Comandos rápidos

### HTTP (porta 8000)

```bash
chmod +x serve_api.sh
./serve_api.sh
```

### HTTPS (porta 443, domínio)

```bash
chmod +x serve_api_https.sh
./serve_api_https.sh
```

### Ativação automática (ambos)

```bash
cp *.service /etc/systemd/system/
systemctl daemon-reexec
systemctl enable logline-api-http
systemctl enable logline-api-https
systemctl start logline-api-http
systemctl start logline-api-https
```

## Testar

```bash
curl http://164.92.209.55:8000
curl -k https://voulezvous.ai
```

Use `-k` para ignorar o aviso de certificado autoassinado.
